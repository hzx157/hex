//
//  UserInfo.m
//  xiushouguzhu_ios
//
//  Created by Interest on 15/3/19.
//  Copyright (c) 2015年 Interest. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

@end
