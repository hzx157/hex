//
//  OneKeyOrderViewController.h
//  xiushouguzhu_ios
//
//  Created by Interest on 15/3/17.
//  Copyright (c) 2015年 Interest. All rights reserved.
//

#import "CommonViewController.h"
#import "CustomIOS7AlertView.h"
#import "HZAreaPickerView.h"

@interface OneKeyOrderViewController : CommonViewController<CustomIOS7AlertViewDelegate,HZAreaPickerDelegate, UITableViewDataSource, UITableViewDelegate>



@end
