//
//  EvaluteSimpleTableViewController.h
//  xiushouguzhu_ios
//
//  Created by Interest on 15/3/16.
//  Copyright (c) 2015年 Interest. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EvaluteSimpleTableViewController : UITableViewController

@property (strong,nonatomic) NSString *nurseMemEnCrypId;

@property (assign,nonatomic) BOOL isPush;

@end
