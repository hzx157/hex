//
//  OrderDetailTableViewController.h
//  xiushouguzhu_ios
//
//  Created by Interest on 15/3/16.
//  Copyright (c) 2015年 Interest. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderDetailTableViewController : UITableViewController

@property (strong,nonatomic) NSDictionary *dicData;
@property (assign,nonatomic) BOOL isPush;

@end
