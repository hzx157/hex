//
//  GuideViewController.h
//  Poly
//
//  Created by Interest on 15/1/31.
//  Copyright (c) 2015年 helloworld. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GuideViewController : UIViewController

@end
