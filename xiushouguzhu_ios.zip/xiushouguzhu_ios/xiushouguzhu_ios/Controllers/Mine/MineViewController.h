//
//  MineViewController.h
//  xiushouguzhu_ios
//
//  Created by Interest on 15/3/11.
//  Copyright (c) 2015年 Interest. All rights reserved.
//

#import "CommonViewController.h"

@interface MineViewController : CommonViewController<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>

@end
