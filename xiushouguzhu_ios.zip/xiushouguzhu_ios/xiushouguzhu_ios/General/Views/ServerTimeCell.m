//
//  ServerTimeCell.m
//  xiushouguzhu_ios
//
//  Created by Interest on 15/3/16.
//  Copyright (c) 2015年 Interest. All rights reserved.
//

#import "ServerTimeCell.h"

@implementation ServerTimeCell

- (void)awakeFromNib {
    // Initialization code
}

@end
