//
//  MinStar.h
//  DuoDuoM
//
//  Created by Interest on 15/3/5.
//  Copyright (c) 2015年 interest. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MinStar : UIView

- (void)setStarCount:(int)count;

@end
